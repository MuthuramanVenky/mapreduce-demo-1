import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class offence {
	
	public static class MapClass extends Mapper<LongWritable,Text,Text,DoubleWritable>
	   {
	
			
	      public void map(LongWritable key, Text value, Context context)
	      {	    
	    	 
	         try{
	        	 String[] parts = value.toString().split(",");
	        	 double val = Double.parseDouble(parts[1]);
	        	 
	  	 		   Text outk = new Text(parts[0]);
	  	 		   DoubleWritable outv = new DoubleWritable(val);
	  	 		   context.write(new Text(outk),outv);
	  	 	   
		             
	         }
	         catch(Exception e)
	         {
	            System.out.println(e.getMessage());
	         }
	      }
	        
	   }
	
	  public static class ReduceClass extends Reducer<Text,DoubleWritable,Text,DoubleWritable>
	   {
	        

		    public void reduce(Text key, Iterable<DoubleWritable> values,Context context) throws IOException, InterruptedException {
		    	double sum = 0;
		    	double count=0;
		    	double count1=0;
		    	double offenceper;
		    	DoubleWritable result= new DoubleWritable();
				
		         for (DoubleWritable val : values)
		         {       	
		        	if(val.get()>65);
		        	
		        	{
		        		count++;
		        	}
		        	count1++;
		         }
		         offenceper=(count/count1)*100;
		         result.set(offenceper);
			      
			      	     
		      context.write(key, result);
		    }
	   }
	  public static void main(String[] args) throws Exception {
		    Configuration conf = new Configuration();
		    conf.set("mapreduce.output.textoutputformat.separator",",");
		    Job job = Job.getInstance(conf, "STD Calls");
		    job.setJarByClass(offence.class);
		    job.setMapperClass(MapClass.class);
		    //job.setCombinerClass(ReduceClass.class);
		    job.setReducerClass(ReduceClass.class);
		    job.setOutputKeyClass(Text.class);
		    job.setOutputValueClass(DoubleWritable.class);
		    job.setNumReduceTasks(1);
		    job.setInputFormatClass(TextInputFormat.class);
		    job.setOutputFormatClass(TextOutputFormat.class);
		    FileInputFormat.addInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    System.exit(job.waitForCompletion(true) ? 0 : 1);
		  }
}