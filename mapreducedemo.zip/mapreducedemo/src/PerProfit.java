import java.io.*;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class PerProfit 
{
	public static class PerMapper extends Mapper<LongWritable, Text, Text, Text>
	{
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			try {
				String[] rec = value.toString().split(";");
				
				//String prod = rec[5];
				String catg = rec[4];
				String cost = rec[7];
				String sales = rec[8];
				String perprof = cost + ',' + sales;
				context.write(new Text(catg), new Text(perprof));			
			} catch (IndexOutOfBoundsException e) {
			} catch (ArithmeticException e1) {
			}
		}
	}
	
	public static class PerReducer extends Reducer<Text, Text, Text, Text>
	{
	    
	    
	    public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException 
	    {
	    	float tot_sales=0;
	        float tot_cost=0;
	        float profit=0;
			
	         for (Text val : values)
	         {    
	        	String[] token = val.toString().split(",");
	        	tot_cost+=Float.parseFloat(token[0]);
	        	tot_sales+=Float.parseFloat(token[1]);
	         }
	         
	      profit = (((tot_sales-tot_cost)/tot_cost)*100);	
	      String myMaxValue = String.format("%f",profit);
	      //context.write(key, result);
	      context.write(key, new Text(myMaxValue));
	      
	    }
	}
	
	public static void main(String[] args) throws Exception {

		if (args.length != 2) {
			System.out
					.printf("Usage: TotalGrossProfit <input dir> <output dir>\n");
			System.exit(-1);
		}

		
		Configuration conf = new Configuration();
		//conf.set("","")
		Job job = Job.getInstance(conf, "Max Amount earned by Customer");

		job.setJarByClass(PerProfit.class);

		//job.setJobName("NYSE Stock");

		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		job.setMapperClass(PerMapper.class);
		//job.setCombinerClass(CustomerReducer.class);
		job.setReducerClass(PerReducer.class);
		//job.setNumReduceTasks(2);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		System.exit(job.waitForCompletion(true) ? 0 : 1);
		
	}
}