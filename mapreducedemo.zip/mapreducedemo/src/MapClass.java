import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.Reducer;


public class MapClass extends Mapper<LongWritable, Text, Text, DoubleWritable>{
		public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
			String value = inpv.toString();
			String eachval[] = value.split(",");
	 	   double val = Double.parseDouble(eachval[3]);
	 	   if(val>174 && val<201)
	 	   {
	 		   Text outk = new Text(eachval[0]);
	 		   DoubleWritable outv = new DoubleWritable(val);
	 		   c.write(new Text("1"),outv);
	 	   }
	    }
}
	
class ReduceClass extends Reducer<Text,DoubleWritable,Text,IntWritable>{
	
	public void reduce(Text inpk,Iterable<DoubleWritable> inpv,Context c) throws IOException, InterruptedException{
		int count = 0;
		for(DoubleWritable v : inpv){
			count++;
		}
		c.write(new Text("Transaction Count"), new IntWritable(count));
	}
}
