import java.awt.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class cashtran{
	
	
	public static class MyMapper extends Mapper<LongWritable,Text, Text, Text> {
		
		HashMap<String,String> hmap = new HashMap<>();
		public void setup(Context context) throws IOException, InterruptedException
		{
			super.setup(context);
			URI[] files = context.getCacheFiles();
			Path p = new Path(files[0]);
			FileSystem fs = FileSystem.get(context.getConfiguration());
			if(p.getName().equals("custs-large.dat"))
			{
				BufferedReader reader = new BufferedReader(new InputStreamReader(fs.open(p)));
				String line = reader.readLine();
				while(line != null) {
					String[] tokens = line.split(",");
					String custid = tokens[0];
					String cname = tokens[1];
					hmap.put(custid, cname);
					line = reader.readLine();
				}
				reader.close();
			}
			if(hmap.isEmpty()){
				throw new IOException("unable to load file");
			}
		}
		protected void map(LongWritable key, Text value, Context context) throws java.io.IOException, InterruptedException 
		{
	        	String row = value.toString();
	        	String[] tokens = row.split(",");
	        	String custid = tokens[2];
	        	String amount = tokens[3];
	        	//String mode = tokens[8];
	        	String name = hmap.get(custid);
	        	if(name!=null)
	        	{
	        		       	
	        	
	        	context.write(new Text(name),new Text(amount));
		}  
		}
	}
	

public class MyCombiner extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text inpK,Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		double amount = 0.0;
		for(Text x: inpV){
			amount += Double.parseDouble(x.toString());
		}
		c.write(new Text("Hello"), new Text(inpK+":"+Double.toString(amount)));
	}

}

	
	public class MyReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		double amount=0.0,max=0.0;
		String name=null;
		Map<String,Double> hm=new HashMap<String,Double>();
		for(Text each: inpV){
			String[] data=each.toString().split(":");
			name=data[0];
			amount=Double.parseDouble(data[1]);
			hm.put(name,amount);
			
		}
		Set<java.util.Map.Entry<String, Double>> set = hm.entrySet();
		ArrayList<Entry<String, Double>> list = new ArrayList<java.util.Map.Entry<String,Double>>(set);
        Collections.sort( list, new Comparator<Map.Entry<String, Double>>()
        {
            public int compare( Map.Entry<String, Double> o1, Map.Entry<String, Double> o2 )
            {
                return (o2.getValue()).compareTo( o1.getValue() );
            }
        } );
        int flag=0;
        for(Map.Entry<String, Double> entry:list){
        	c.write(new Text(entry.getKey().toString()),new Text(""+entry.getValue()+""));
        	flag++;
        	if(flag==1){break;}
        }
	}
}
	
  public static void main(String[] args) 
                  throws IOException, ClassNotFoundException, InterruptedException {
    
	Configuration conf = new Configuration();
	conf.set("mapreduce.output.textoutputformat.separator", ",");
	Job job = Job.getInstance(conf);
    job.setJarByClass(cashtran.class);
    job.setJobName("Map Side Join");
    job.setMapperClass(MyMapper.class);
    job.setCombinerClass(MyCombiner.class);
    job.setReducerClass(MyReducer.class);
    job.addCacheFile(new Path(args[1]).toUri());
    job.setNumReduceTasks(1);
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileSystem.get(conf).delete(new Path(args[2]),true);
    FileOutputFormat.setOutputPath(job, new Path(args[2]));
	System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}

