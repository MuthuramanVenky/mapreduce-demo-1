
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class TotQuantEachProdEachStore {

    public static class MyMapper extends Mapper<LongWritable,Text,Text,Text>
    {
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            String valueArr[] = value.toString().split(",");
            String storeID = valueArr[0];
            String productID = valueArr[1];
            int quantity = Integer.parseInt(valueArr[2]);
            String s_q = storeID + "," + quantity;
            context.write(new Text(productID), new Text(s_q));
        }
    }
    
    public static class MyPartitioner extends Partitioner<Text,Text>
    {
        @Override
        public int getPartition(Text key, Text value, int numOfPartitions)
        {
            String valArr[] = value.toString().split(",");
            if(valArr[0].matches("21"))
            {
                return 0;
            }
            else 
            {
                return 1;
            }
        }
    }
    
    public static class MyReducer extends Reducer<Text,Text,Text,Text>
    {
        public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException
        {
            int totalQuantity= 0;
            String storeID = null;
            for(Text v : value)
            {
                String[] valArr = v.toString().split(",");
                storeID = valArr[0];
                int quantity = Integer.valueOf(valArr[1]);
                totalQuantity+=quantity;
            }
            context.write(new Text(key), new Text(storeID + "," + totalQuantity));
        }
    }
    
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf," ");
        job.setJarByClass(TotQuantEachProdEachStore.class);
        job.setMapperClass(MyMapper.class);
        job.setPartitionerClass(MyPartitioner.class);
        job.setReducerClass(MyReducer.class);
        job.setNumReduceTasks(2);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileSystem.get(conf).delete(new Path(args[1]),true);
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}