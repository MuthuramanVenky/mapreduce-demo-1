
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;



public class Posmapjoin {
	
	
	public static class MyMapper extends Mapper<LongWritable,Text, Text, Text> {
        
		
		private Map<String, String> abMap = new HashMap<String, String>();
		private Text outputKey = new Text();
		private Text outputValue = new Text();
		
		protected void setup(Context context) throws java.io.IOException, InterruptedException{
			
			super.setup(context);

		    URI[] files = context.getCacheFiles(); // getCacheFiles returns null

		    Path p = new Path(files[0]);
		
		
			if (p.getName().equals("store_master")) {
					BufferedReader reader = new BufferedReader(new FileReader(p.toString()));
					String line = reader.readLine();
					while(line != null) {
						String[] tokens = line.split(",");
						String store_id = tokens[0];
						String state=tokens[2];
						abMap.put(store_id, state);
						line = reader.readLine();
					}
					reader.close();
				}
			
		
			
			if (abMap.isEmpty()) {
				throw new IOException("MyError:Unable to load salary data.");
			}


		}

		
        protected void map(LongWritable key, Text value, Context context)
            throws java.io.IOException, InterruptedException {
        	
        	
        	String row = value.toString();//reading the data from Employees.txt
        	String[] tokens = row.split(",");
        	String store_id = tokens[0];
        	String prod_id=tokens[1];
        	String qty=tokens[2];
        	String prodid = abMap.get(store_id);
        	String sal_desig = prodid + "," + qty; 
        	outputKey.set(prod_id);
        	outputValue.set(sal_desig);
      	  	context.write(outputKey,outputValue);
        }  
}
	 public static class MyPartitioner extends Partitioner<Text,Text>
	    {
	        @Override
	        public int getPartition(Text key, Text value, int numOfPartitions)
	        {
	            String tokens[] = value.toString().split(",");
	            if(tokens[1].matches("MAH"))
	            {
	                return 0;
	            }
	            else 
	            {
	                return 1;
	            }
	        }
	    }
	    
	    public static class MyReducer extends Reducer<Text,Text,Text,Text>
	    {
	        public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException
	        {
	            int totalQuantity= 0;
	     
	            for(Text v : value)
	            {
	                String[] valArr = v.toString().split(",");
	                
	                int quantity = Integer.valueOf(valArr[1]);
	                totalQuantity+=quantity;
	            }
	            context.write(new Text(key), new Text(String.valueOf(totalQuantity)));
	        }
	    }
	
  public static void main(String[] args) 
                  throws IOException, ClassNotFoundException, InterruptedException {
    
	Configuration conf = new Configuration();
	conf.set("mapreduce.output.textoutputformat.separator", ",");
	Job job = Job.getInstance(conf);
    job.setJarByClass(Posmapjoin.class);
    job.setJobName("Map Side Join");
    job.setMapperClass(MyMapper.class);
    job.setPartitionerClass(MyPartitioner.class);
    job.setReducerClass(MyReducer.class);
    job.addCacheFile(new Path(args[1]).toUri());
    job.setNumReduceTasks(2);
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileSystem.get(conf).delete(new Path(args[2]),true);
    FileOutputFormat.setOutputPath(job, new Path(args[2]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
}
}