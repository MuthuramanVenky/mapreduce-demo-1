import java.io.*;


import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class retailmonth {
	public static class MapClass extends Mapper<LongWritable,Text,Text,Text>
	   {
	      public void map(LongWritable key, Text value, Context context)
	      {	    	  
	         try{
	            String[] str = value.toString().split(";");
	            String dt=str[0];
	            String custid =str[1].trim();
	            String sales=str[8];
	            String mykey="all";
	            String myvalue=dt+','+ custid+','+sales;
	            context.write(new Text(mykey),new Text(myvalue));
	         }
	         catch(Exception e)
	         {
	            System.out.println(e.getMessage());
	         }
	      }
	   }
	
	  public static class ReduceClass extends Reducer<Text,Text,NullWritable,Text>
	   {
		    
		    
		    public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException {
		      long maxvalue=0;
		      String custid="";
		      String dt="";
		      for(Text val:values)
		      {
		    	  String[] token =val.toString().split(",");
		    	  if(Long.parseLong(token[2])>maxvalue)
		    	  {
		    		  maxvalue=Long.parseLong(token[2]);
		    		  dt=token[0];
		    		  custid=token[1];
		    	  }
		      }
		      String mymaxvalue=String.format("%d", maxvalue);
		      String myvalue=dt+','+custid+','+mymaxvalue;
		      context.write(NullWritable.get(),new Text(myvalue));
		      //context.write(key, new LongWritable(sum));
		      
		    }
	   }
	  public static void main(String[] args) throws Exception {
		    Configuration conf = new Configuration();
		    //conf.set("name", "value")
		    //conf.set("mapreduce.input.fileinputformat.split.minsize", "134217728");
		    Job job = Job.getInstance(conf, "Monthly amount total");
		    job.setJarByClass(retailmonth.class);
		    job.setMapperClass(MapClass.class);
		    //job.setCombinerClass(ReduceClass.class);
		    job.setReducerClass(ReduceClass.class);
		    job.setNumReduceTasks(1);
		    job.setMapOutputKeyClass(Text.class);
		    job.setMapOutputValueClass(Text.class);
		    job.setOutputKeyClass(NullWritable.class);
		    job.setOutputValueClass(Text.class);
		    FileInputFormat.addInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    System.exit(job.waitForCompletion(true) ? 0 : 1);
		  }
	
}
