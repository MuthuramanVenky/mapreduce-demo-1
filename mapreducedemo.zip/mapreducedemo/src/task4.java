
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.google.common.collect.Lists;



public class task4{

public static class MyMapper extends Mapper<LongWritable,Text, Text, IntWritable> {
		
		
		protected void map(LongWritable key, Text value, Context context) throws java.io.IOException, InterruptedException 
		{
	        	String row = value.toString();
	        	String[] tokens = row.split("\t");
	        	String empname = tokens[2];
	        	String year = tokens[7];
	        	String empname1=year+","+empname;
	        	
	        	context.write(new Text(empname1),new IntWritable(1));
	        	
		}  
		}
	
	



	
    public static class MyReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {
    	private TreeMap < Text,DoubleWritable > Top5 = new TreeMap < Text,DoubleWritable > ();
	public void reduce(Text inpK, Iterable<IntWritable> inpV, Context c) throws IOException, InterruptedException{
		
		double sum=0;
		for(IntWritable inp:inpV){
				sum+=inp.get();
		}
		DoubleWritable i = new DoubleWritable(sum);
	      
    c.write(new Text(inpK), i);
    Top5.put(new Text(inpK),i);
    Map<Text,DoubleWritable> mout = Top5.descendingMap();
//    c.write(new Text(inpK), i);
//    if (Top5.size() > 5)
  //      Top5.remove(Top5.firstKey());

}
protected void cleanup(Context context) throws IOException,
InterruptedException {
  Comparator<Map.Entry<Integer, String>> abc = new Comparator<Map.Entry<Integer, String>>() {
        @Override
        public int compare(Map.Entry<Integer, String> left, Map.Entry<Integer, String> right) {
            return left.getValue().compareTo(right.getValue());
        }
    };

    // create a list of map entries
    List<Map.Entry<Integer, String>> candyBars = new ArrayList<Map.Entry<Integer, String>>();

    

    // sort the collection
    Collections.sort(candyBars, abc.reverse());


  
     //context.write(Top5.descendingMap().values(),i);  
}
			
					
			
		}
    
		
	
    public static class CaderPartitioner extends
    Partitioner < Text, IntWritable >
    {
       @Override
       public int getPartition(Text key, IntWritable value, int numReduceTasks)
       {
    	   String[] str = key.toString().split(",");
           String year = str[0];
           
           
           if(year.equals("2011"))
           {
              return 0;
           }
           else if(year.equals("2012"))
           {
              return 1 ;
           }
           else if(year.equals("2013"))
           {
              return 2;
           }
           else if(year.equals("2014"))
           {
         	  return 3;
           }
           else if(year.equals("2015"))
           {
         	  return 4;
           }
           else
           {
         	  return 5;
           }
        }
     }		
	
  public static void main(String[] args) 
                  throws IOException, ClassNotFoundException, InterruptedException {
    
	Configuration conf = new Configuration();
	conf.set("mapreduce.output.textoutputformat.separator", ",");
	Job job = Job.getInstance(conf);
    job.setJarByClass(task4.class);
    job.setJobName("task 4");
    job.setMapperClass(task4.MyMapper.class);
    job.setPartitionerClass(CaderPartitioner.class);
    job.setReducerClass(task4.MyReducer.class);
    job.setNumReduceTasks(6);
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(IntWritable.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(DoubleWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}


