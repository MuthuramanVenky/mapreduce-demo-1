

import java.io.*;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.conf.*;

import org.apache.hadoop.fs.*;

import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;

import org.apache.hadoop.util.*;

public class ViableProd extends Configured implements Tool
{
   //Map class
	
   public static class MapClass extends Mapper<LongWritable,Text,Text,Text>
   {
      public void map(LongWritable key, Text value, Context context)
      {
         try{
            String[] str = value.toString().trim().split(";");
            String age = str[2].trim();
            String prodSubClass = str[4].trim();
            String prodId = str[5].trim();
            String cost = str[7].trim();
            String sales = str[8].trim();

            String myValue = age + ',' + prodSubClass + ',' + cost + ',' + sales +  ','+ prodId;
            context.write(new Text(age), new Text(myValue));
         }
         catch(Exception e)
         {
            System.out.println(e.getMessage());
         }
      }
   }
   
   //Reducer class
	
   public static class ReduceClass extends Reducer<Text,Text,Text,Text>
   {
      public int profit = 0;//, max = 0;
      private Text outputKey = new Text();
      public void reduce(Text key, Iterable <Text> values, Context context) throws IOException, InterruptedException
      {
         profit = 0;
       //  max = 0;
		
         for (Text val : values)
         {
        	
//        	outputKey.set(key);
        	String [] str = val.toString().trim().split(",");
            
            {	
            	int cost = Integer.parseInt(str[2].trim());
            	int sales = Integer.parseInt(str[3].trim()); 
            	profit = sales - cost;
         /*   	if(cost > max){
            		max = cost;
            		String mykey = key.toString() + ',' + str[4].trim()+ ',' + str[1].trim() + ',' + str[0].trim();
            		outputKey.set(mykey);}*/
            	if(profit >= 0){
            		String myValue = key.toString() + ',' + str[1].trim() + ',' + str[0].trim()+ ',' + Integer.toString(profit);
            		outputKey.set(str[1].trim());
            		context.write(outputKey,new Text( myValue));
            	}

            }	
         }
			
      //  context.write(outputKey, new IntWritable(max));
      }
   }
   
   //Partitioner class
	
   public static class CaderPartitioner extends
   Partitioner < Text, Text >
   {
      @Override
      public int getPartition(Text key, Text value, int numReduceTasks)
      {
    	  
    	  /*: 10 possible values 
          A <25,B 25-29,C 30-34,D 35-39,E 40-44,F 45-49,G 50-54,H 55-59,I 60-64,J >65 */
         String[] str = value.toString().trim().split(",");
       //  String age = str[0].trim();
         String age = key.toString().trim();
         
         switch(age)
         {
         case "A":
        	 return 0;
         case "B":
         {
            return 1;
         }
         case "C":
         {
            return 2;
         }
         case "D":
         {
            return 3;
         }
         case "E":
         {
            return 4;
         }
         case "F":
         {
            return 5;
         }
         case "G":
         {
            return 6;
         }
         case "H":
         {
            return 7 ;
         }
         case "I":
         {
            return 8;
         }
         default:
         {
            return 9;
         }
        }
      }
   }
   

   public int run(String[] arg) throws Exception
   {
	  Configuration conf = new Configuration();
	  Job job = Job.getInstance(conf);
	  job.setJarByClass(ViableProd.class);
	  job.setJobName("Viable prod");
      FileInputFormat.setInputPaths(job, new Path(arg[0]));
      FileOutputFormat.setOutputPath(job,new Path(arg[1]));
		
      job.setMapperClass(MapClass.class);
		
      job.setMapOutputKeyClass(Text.class);
      job.setMapOutputValueClass(Text.class);
      
      //set partitioner statement
		
      job.setPartitionerClass(CaderPartitioner.class);
      job.setReducerClass(ReduceClass.class);
      job.setNumReduceTasks(10);
      job.setInputFormatClass(TextInputFormat.class);
		
      job.setOutputFormatClass(TextOutputFormat.class);
      job.setOutputKeyClass(Text.class);
      job.setOutputValueClass(Text.class);
		
      System.exit(job.waitForCompletion(true)? 0 : 1);
      return 0;
   }
   
   public static void main(String ar[]) throws Exception
   {
      ToolRunner.run(new Configuration(), new ViableProd(),ar);
      System.exit(0);
   }
}