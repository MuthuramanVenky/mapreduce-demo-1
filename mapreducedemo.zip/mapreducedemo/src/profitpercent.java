
import java.io.*;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class profitpercent {
	public static class MapClass extends Mapper<LongWritable, Text, Text, FloatWritable>
	{
	
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		try {
			String[] record = value.toString().split(";");
			
			String stockSymbol = record[5];
			float cp = Float.valueOf(record[7]);
			float sp = Float.valueOf(record[8]);
			float profper = ((sp - cp)/cp)*100;
			//stock_sym.set(stockSymbol);
			//percent.set(percentChange);
			//context.write(stock_sym, percent);
			context.write(new Text(stockSymbol), new FloatWritable(profper));
			
		} catch (IndexOutOfBoundsException e) {
		} catch (ArithmeticException e1) {
		}
	}
	}
	
	  public static class ReduceClass extends Reducer<Text,FloatWritable,Text,FloatWritable>
	   {
		    private FloatWritable result = new FloatWritable();
		    
		    public void reduce(Text key, Iterable<FloatWritable> values,Context context) throws IOException, InterruptedException {
		      long sum = 0;
				
		         
		      result.set(sum);		      
		      context.write(key, result);
		      //context.write(key, new LongWritable(sum));
		      
		    }
	   }
	  public static void main(String[] args) throws Exception {
		    Configuration conf = new Configuration();
		    //conf.set("name", "value")
		    //conf.set("mapreduce.input.fileinputformat.split.minsize", "134217728");
		    Job job = Job.getInstance(conf, "Monthly amount total");
		    job.setJarByClass(profitpercent.class);
		    job.setMapperClass(MapClass.class);
		    //job.setCombinerClass(ReduceClass.class);
		    job.setReducerClass(ReduceClass.class);
		    job.setNumReduceTasks(0);
		    job.setOutputKeyClass(Text.class);
		    job.setOutputValueClass(FloatWritable.class);
		    FileInputFormat.addInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    System.exit(job.waitForCompletion(true) ? 0 : 1);
		  }
	
}
