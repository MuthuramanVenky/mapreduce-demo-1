
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class studentaverage {
	
	public static class MapClass extends Mapper<LongWritable,Text,Text,FloatWritable>
	   {
	      public void map(LongWritable key, Text value, Context context)
	      {	    	  
	         try{
	            String[] str = value.toString().split(",");	 
	            float vol = Float.parseFloat(str[2]);
	            context.write(new Text(str[3]),new FloatWritable(vol));
	         }
	         catch(Exception e)
	         {
	            System.out.println(e.getMessage());
	         }
	      }
	   }
	         
	   
	
	public static class ReduceClass extends Reducer<Text,FloatWritable,Text,FloatWritable>
	   {
		    
		    
		    public void reduce(Text key, Iterable<FloatWritable> values,Context context) throws IOException, InterruptedException {
		      float sum = 0;
		      float count=0;
		      float avg=0;
				
		         for (FloatWritable val : values)
		         {       	
		        	sum += val.get();
		        	count++;
		         }
		         avg=sum/count;
		         
			      
			      	      FloatWritable Result = new FloatWritable();
			      	      Result.set((float)avg);
		      context.write(key, Result);
		      //context.write(key, new LongWritable(sum));
		      
		    }
	   }
	  public static void main(String[] args) throws Exception {
		    Configuration conf = new Configuration();
		    conf.set("mapreduce.output.textoutputformat.separator",",");
		    Job job = Job.getInstance(conf, "STD Calls");
		    job.setJarByClass(studentaverage.class);
		    job.setMapperClass(MapClass.class);
		    job.setCombinerClass(ReduceClass.class);
		    job.setReducerClass(ReduceClass.class);
		    job.setNumReduceTasks(1);
		    job.setMapOutputKeyClass(Text.class);
		    job.setMapOutputValueClass(FloatWritable.class);
		    job.setOutputKeyClass(Text.class);
		    job.setOutputValueClass(FloatWritable.class);
		    job.setInputFormatClass(TextInputFormat.class);
		    job.setOutputFormatClass(TextOutputFormat.class);
		    FileInputFormat.addInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    System.exit(job.waitForCompletion(true) ? 0 : 1);
		  }
}