import java.io.*;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.conf.*;

import org.apache.hadoop.fs.*;

import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;

import org.apache.hadoop.util.*;

public class viable extends Configured implements Tool
{
   //Map class
	
   public static class MapClass extends Mapper<LongWritable,Text,Text,Text>
   {
      public void map(LongWritable key, Text value, Context context)
      {
         try{
            String[] str = value.toString().split(";");
            String prodid=str[5];
            String prodsubcat = str[4];
            String cost = str[7];
            String age = str[2];
            String sales = str[8];
            String Value = age + ','+ prodsubcat + ',' + cost + ',' + sales;
            context.write(new Text(prodid), new Text(Value));
         }
         catch(Exception e)
         {
            System.out.println(e.getMessage());
         }
      }
   }
   
   //Reducer class
	
   public static class ReduceClass extends Reducer<Text,Text,Text,Text>
   {
      
      private Text outputKey = new Text();
      float totsales=0;
      float totcost=0;
      float profit=0;
      public void reduce(Text key, Iterable <Text> values, Context context) throws IOException, InterruptedException
      {
			
         for (Text val : values)
         {
        	
//        	outputKey.set(key);
        	String [] str = val.toString().split(",");
        	String age =str[0];
        	String prodsubcat=str[1];
        	totcost+=Float.parseFloat(str[2]);
        	totsales+=Float.parseFloat(str[3]);
         
        	profit=totsales-totcost;
        	
        	if(profit>0)

        	{
        	String myMaxValue = String.format("%f",profit);
        	String myVal=age+','+prodsubcat+','+myMaxValue;
        		
			
         context.write(key,new Text(myMaxValue));
      }
         }
      }
   }
   
   //Partitioner class
	
   public static class CaderPartitioner extends
   Partitioner < Text, Text >
   {
      @Override
      public int getPartition(Text key, Text value, int numReduceTasks)
      {
         String[] str = value.toString().split(",");
         String age = key.toString();
         
         
         switch(age)
         {
         case "A":
        	 return 0;
         case "B":
         {
            return 1;
         }
         case "C":
         {
            return 2;
         }
         case "D":
         {
            return 3;
         }
         case "E":
         {
            return 4;
         }
         case "F":
         {
            return 5;
         }
         case "G":
         {
            return 6;
         }
         case "H":
         {
            return 7 ;
         }
         case "I":
         {
            return 8;
         }
         default:
         {
            return 9;
         }
        }
      }
   }
   

   public int run(String[] arg) throws Exception
   {
	
	   
	  Configuration conf = new Configuration();
	  Job job = Job.getInstance(conf);
	  job.setJarByClass(viable.class);
	  job.setJobName("Top viable products");
      FileInputFormat.setInputPaths(job, new Path(arg[0]));
      FileOutputFormat.setOutputPath(job,new Path(arg[1]));
		
      job.setMapperClass(MapClass.class);
		
      job.setMapOutputKeyClass(Text.class);
      job.setMapOutputValueClass(Text.class);
      
      //set partitioner statement
		
      job.setPartitionerClass(CaderPartitioner.class);
      job.setReducerClass(ReduceClass.class);
      job.setNumReduceTasks(10);
      job.setInputFormatClass(TextInputFormat.class);
		
      job.setOutputFormatClass(TextOutputFormat.class);
      job.setOutputKeyClass(Text.class);
      job.setOutputValueClass(Text.class);
		
      System.exit(job.waitForCompletion(true)? 0 : 1);
      return 0;
   }
   
   public static void main(String ar[]) throws Exception
   {
      ToolRunner.run(new Configuration(), new MyPartitioner(),ar);
      System.exit(0);
   }
}